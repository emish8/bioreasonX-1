import streamlit as st
import sys
from pathlib import Path
import logging

# Streamlit logging handler to capture logs in UI
if "log_messages" not in st.session_state:
    st.session_state.log_messages = []

class StreamlitLogHandler(logging.Handler):
    def emit(self, record):
        msg = self.format(record)
        st.session_state.log_messages.append(msg)

# Configure root logger only once
_root_logger = logging.getLogger()
_root_logger.setLevel(logging.INFO)
_handler = StreamlitLogHandler()
_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
if not any(isinstance(h, StreamlitLogHandler) for h in _root_logger.handlers):
    _root_logger.addHandler(_handler)

# Add project root to path for local module imports
sys.path.append(str(Path(__file__).resolve().parent))

# Import render pages
from frontend.pages.Home import render_home
from frontend.pages.Analysis import render_analysis
from frontend.pages.EvidenceExplorer import render_evidence_explorer
from frontend.pages.ExplainableAI import render_explainable_ai
from frontend.pages.ReportGenerator import render_report_generator

from backend.utils.config import has_gemini_credentials, logger
import re

def get_placeholder_answer(question: str) -> str:
    """Generate an answer for the given question using the knowledge graph.
    This queries the biomedical graph to provide relevant information.
    """
    from backend.knowledge_graph.graph_builder import BiomedicalGraph
    import re
    
    question_lower = question.lower()
    
    # Initialize graph engine
    graph_engine = BiomedicalGraph()
    
    # Check if question is about specific entities in the graph
    # Look for known mutations, genes, drugs, etc.
    known_entities = []
    
    # Get all nodes from the graph
    nodes, edges = graph_engine.get_pyvis_elements()
    
    # Extract entity names from nodes
    for node in nodes:
        entity_name = node['label'].lower()
        if entity_name in question_lower:
            known_entities.append(node)
    
    graph_engine.close()
    
    if known_entities:
        # Build response based on found entities
        response_parts = []
        for entity in known_entities:
            entity_name = entity['label']
            category = entity['category']
            properties = entity.get('properties', {})
            
            response_parts.append(f"**{entity_name}** ({category})")
            
            # Add properties
            if properties:
                for key, value in properties.items():
                    response_parts.append(f"- {key}: {value}")
            
            # Find related edges
            related_edges = [edge for edge in edges if edge['from'] == entity_name or edge['to'] == entity_name]
            if related_edges:
                response_parts.append("\n**Related connections:**")
                for edge in related_edges[:5]:  # Limit to 5 connections
                    if edge['from'] == entity_name:
                        response_parts.append(f"- → {edge['to']} ({edge['label']})")
                    else:
                        response_parts.append(f"- ← {edge['from']} ({edge['label']})")
        
        return "\n".join(response_parts)
    
    # Check for general questions about the knowledge graph
    if any(keyword in question_lower for keyword in ['knowledge graph', 'graph', 'network', 'relationships']):
        return """The **Knowledge Graph** in BioReason-X is a biomedical network that shows relationships between:

**Nodes (Biological Entities):**
- **Mutations** (orange): Genetic variants like BRCA1 c.5266dupC, EGFR L858R, BRAF V600E
- **Genes** (blue): BRCA1, EGFR, BRAF
- **Proteins** (purple): BRCA1 Protein, EGFR kinase, BRAF V600E Kinase
- **Pathways** (teal): Homologous Recombination, MAPK Signaling
- **Diseases** (red): Breast and Ovarian Cancer, Lung Adenocarcinoma, Metastatic Melanoma
- **Drugs** (green): Olaparib, Osimertinib, Vemurafenib
- **Publications** (gold): Supporting research articles

**Edges (Relationships):**
- Shows how mutations affect genes
- How genes encode proteins
- How proteins participate in pathways
- How pathways relate to diseases
- How drugs target proteins
- How publications support drug efficacy

The graph is built from agent outputs and RAG ingestion, providing explainable AI reasoning for clinical decisions."""
    
    # Check for questions about specific mutations
    if 'mutation' in question_lower or 'mutant' in question_lower:
        mutation_info = """The system currently tracks these key mutations:

**BRCA1 c.5266dupC**
- Type: Frameshift mutation
- Clinical significance: Pathogenic
- Affects: BRCA1 gene (tumor suppressor)
- Associated with: Breast and Ovarian Cancer
- Targeted therapy: Olaparib (PARP inhibitor)

**EGFR L858R**
- Type: Missense mutation (Exon 21)
- Clinical significance: Pathogenic (Somatic)
- Affects: EGFR gene (epidermal growth factor receptor)
- Associated with: Lung Adenocarcinoma
- Targeted therapy: Osimertinib (3rd-gen EGFR TKI)

**BRAF V600E**
- Type: Missense mutation (Codon 600)
- Clinical significance: Pathogenic (Somatic)
- Affects: BRAF gene (serine/threonine-protein kinase)
- Associated with: Metastatic Melanoma
- Targeted therapy: Vemurafenib (BRAF inhibitor)"""
        return mutation_info
    
    # Check for questions about drugs/therapies
    if any(keyword in question_lower for keyword in ['drug', 'therapy', 'treatment', 'medicine']):
        drug_info = """The system includes information about these targeted therapies:

**Olaparib**
- Class: PARP Inhibitor
- Action: Induces synthetic lethality
- Targets: BRCA1 Protein
- Used for: BRCA1 mutation carriers
- Supported by: PMID-29402511

**Osimertinib**
- Class: 3rd-gen EGFR TKI
- Action: Covalent inhibitor
- Targets: EGFR kinase
- Used for: EGFR L858R mutation
- Supported by: PMID-26458312

**Vemurafenib**
- Class: BRAF inhibitor
- Action: Selective monomer inhibitor
- Targets: BRAF V600E Kinase
- Used for: Metastatic Melanoma
- Supported by: PMID-21876543"""
        return drug_info
    
    # Default response for other questions
    return f"I can help you understand the biomedical knowledge graph, mutations, drugs, and their relationships. Try asking about specific entities like 'BRCA1', 'EGFR L858R', or general topics like 'knowledge graph', 'mutations', or 'drugs'."

def main():
    # 1. Config main Streamlit frame
    st.set_page_config(
        page_title="BioReason-X | Clinical Intelligence Platform",
        page_icon="🧬",
        layout="wide",
        initial_sidebar_state="expanded"
    )

    # 2. Premium styling injections
    st.markdown(
        """
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;800&family=Inter:wght@300;400;600;700&display=swap');
            
            /* Global Font Updates */
            html, body, [class*="css"], .stMarkdown {
                font-family: 'Inter', sans-serif;
            }
            h1, h2, h3, h4, h5, h6 {
                font-family: 'Montserrat', sans-serif;
                font-weight: 600;
            }

            # --- Q&A Chatbot UI ---
            # Display captured logs in a fixed bottom‑left overlay
            
            /* Custom styling for primary actions button */
            div.stButton > button:first-child {
                background-color: var(--primary-color, #1A365D);
                color: #FFFFFF;
                border-radius: 8px;
                border: 1px solid var(--primary-color, #1A365D);
                font-weight: 600;
                transition: all 0.25s ease;
            }
            div.stButton > button:first-child:hover {
                background-color: var(--primary-color, #2B6CB0);
                border-color: var(--primary-color, #2B6CB0);
                color: #FFFFFF;
                box-shadow: 0 4px 10px rgba(43, 108, 176, 0.25);
                opacity: 0.9;
            }
            
            /* Sidebar customizations adapting to dark theme */
            [data-testid="stSidebar"] {
                background-color: var(--secondary-background-color);
                border-right: 1px solid var(--border-color, #E2E8F0);
            }

            /* Sidebar Title */
            .sidebar-title {
                font-family: 'Montserrat', sans-serif;
                font-size: 1.5rem;
                color: var(--text-color);
                margin: 0;
            }
            
            /* Home page styles */
            .hero-subtitle {
                font-size: 1.25rem;
                font-weight: 400;
                color: var(--text-color);
                opacity: 0.8;
                margin-top: 10px;
            }
            .analysis-card {
                background-color: var(--secondary-background-color);
                border: 1.5px solid var(--border-color, #E2E8F0);
                border-radius: 12px;
                padding: 25px;
                margin-bottom: 20px;
                box-shadow: 0 4px 6px rgba(0,0,0,0.02);
            }
            .analysis-card h4 {
                margin-top: 0;
                font-family: 'Montserrat', sans-serif;
                color: var(--text-color);
            }

            /* Evidence Explorer styles */
            .evidence-card {
                background-color: var(--secondary-background-color);
                border: 1px solid var(--border-color, #E2E8F0);
                border-radius: 8px;
                padding: 20px;
                margin-bottom: 20px;
                box-shadow: 0 1px 3px rgba(0,0,0,0.02);
            }
            .evidence-title {
                margin: 10px 0;
                font-size: 1.15rem;
                font-family: 'Montserrat', sans-serif;
                color: var(--text-color);
            }
            .evidence-abstract {
                font-size: 0.95rem;
                line-height: 1.5;
                color: var(--text-color);
                opacity: 0.8;
                margin-top: 10px;
                font-style: italic;
            }
            .evidence-meta {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 10px;
                flex-wrap: wrap;
                gap: 8px;
            }
            .badge {
                font-size: 0.85rem;
                font-weight: 600;
                padding: 4px 10px;
                border-radius: 6px;
            }
            .badge-id {
                font-weight: 700;
                font-size: 0.95rem;
                color: var(--primary-color);
                background-color: rgba(43, 108, 176, 0.15);
            }
            .badge-source {
                color: var(--text-color);
                background-color: rgba(128, 128, 128, 0.15);
            }
            .badge-relevance {
                font-weight: 700;
                color: #319795;
                background-color: rgba(49, 151, 149, 0.15);
            }
        </style>
        """,
        unsafe_allow_html=True
    )

    # 3. Sidebar management
    st.sidebar.markdown(
        """
        <div style="text-align: center; padding: 10px 0;">
            <h2 class="sidebar-title">🧬 BioReason-X</h2>
            <span style="font-size: 0.8rem; color: #718096; font-weight: 600;">v1.0.0 (Enterprise)</span>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Active page tracker in session state
    if "active_page" not in st.session_state:
        st.session_state["active_page"] = "🏠 Home Overview"

    # Sidebar Navigation Option list
    nav_options = [
        "🏠 Home Overview",
        "📊 Analysis Dashboard",
        "🔍 Evidence Explorer",
        "🧠 Explainable AI",
        "📄 Report Generator"
    ]
    
    # Render sidebar selections
    selection = st.sidebar.radio(
        "Navigation Menu:",
        options=nav_options,
        index=nav_options.index(st.session_state["active_page"])
    )
    
    st.session_state["active_page"] = selection

    # Sidebar utility: Current target indicator
    if "pipeline_results" in st.session_state:
        current_mut = st.session_state["pipeline_results"].get("mutation_input", "None")
        st.sidebar.markdown("---")
        st.sidebar.markdown(f"🧬 **Current Target:**  \n`{current_mut}`")
        
        if st.sidebar.button("🗑️ Reset Analysis Session", use_container_width=True):
            logger.info("Clearing active pipeline analysis session.")
            st.session_state.pop("pipeline_results", None)
            st.session_state.pop("mutation_query", None)
            st.session_state["active_page"] = "🏠 Home Overview"
            st.rerun()

    st.sidebar.markdown("---")
    st.sidebar.info("Designed for molecular tumor boards and genomics research institutes.")

    # 4. Route views
    if selection == "🏠 Home Overview":
        render_home()
    elif selection == "📊 Analysis Dashboard":
        render_analysis()
    elif selection == "🔍 Evidence Explorer":
        render_evidence_explorer()
    elif selection == "🧠 Explainable AI":
        render_explainable_ai()
    elif selection == "📄 Report Generator":
        render_report_generator()

    # 5. Q&A Chatbot UI - Simple and Reliable
    if "qa_history" not in st.session_state:
        st.session_state.qa_history = []
    
    st.markdown("---")
    st.markdown("## 🤖 BioReason Assistant")
    st.markdown("Ask questions about the knowledge graph, mutations, drugs, and their relationships.")
    
    # Chat input
    chat_message = st.text_input("Your question:", key="chat_input_main", placeholder="e.g., 'What is the knowledge graph?' or 'Tell me about BRCA1'")
    
    if st.button("Send Question", key="send_question"):
        if chat_message:
            answer = get_placeholder_answer(chat_message)
            st.session_state.qa_history.append({"role": "user", "content": chat_message})
            st.session_state.qa_history.append({"role": "assistant", "content": answer})
            st.rerun()
    
    # Display chat history
    if st.session_state.qa_history:
        st.markdown("### Conversation History")
        for i, msg in enumerate(st.session_state.qa_history):
            if msg["role"] == "user":
                st.markdown(f"**👤 You:** {msg['content']}")
            else:
                # Use st.markdown to render the assistant's response with proper formatting
                st.markdown(f"**🤖 Assistant:**")
                st.markdown(msg['content'])
            st.markdown("---")
    
    # Clear chat button
    if st.button("Clear Chat History"):
        st.session_state.qa_history = []
        st.rerun()

    # Log overlay (fixed bottom‑left)
    if st.session_state.get("log_messages"):
        log_html = f"<div style='position:fixed; bottom:20px; left:20px; width:300px; max-height:180px; overflow:auto; background:rgba(255,255,255,0.9); border:1px solid #E2E8F0; border-radius:6px; padding:8px; font-size:0.85rem; z-index:1000;'><strong>Logs</strong><br>{'<br>'.join(st.session_state.log_messages[-20:])}</div>"
        st.markdown(log_html, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
